from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

DATABASE = "files.db"


# =========================================================
# DATABASE
# =========================================================

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            size INTEGER NOT NULL,
            value INTEGER NOT NULL,
            category TEXT DEFAULT ''
        )
    """)

    conn.commit()
    conn.close()


# =========================================================
# HELPERS
# =========================================================

def get_all_files():
    conn = get_db()

    rows = conn.execute("""
        SELECT id, name, size, value, category
        FROM files
        ORDER BY id
    """).fetchall()

    conn.close()

    return [dict(row) for row in rows]


def validate_file_data(data):
    if not data:
        return None, "JSON data is required"

    name = data.get("name")
    size = data.get("size")
    value = data.get("value")
    category = data.get("category", "")

    if name is None or size is None or value is None:
        return None, "name, size and value are required"

    try:
        size = int(size)
        value = int(value)
    except (ValueError, TypeError):
        return None, "size and value must be numbers"

    if size <= 0:
        return None, "size must be greater than 0"

    if value < 0:
        return None, "value cannot be negative"

    return {
        "name": str(name),
        "size": size,
        "value": value,
        "category": str(category)
    }, None


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():
    return jsonify({
        "message": "File Storage Packing Optimizer API",
        "status": "Running",
        "endpoints": [
            "GET /api/files",
            "POST /api/files",
            "DELETE /api/files/<id>",
            "POST /api/sample",
            "POST /api/solve"
        ]
    })


# =========================================================
# GET ALL FILES
# =========================================================

@app.route("/api/files", methods=["GET"])
def get_files():
    return jsonify(get_all_files())


# =========================================================
# ADD FILE
# =========================================================

@app.route("/api/files", methods=["POST"])
def add_file():

    data = request.get_json(silent=True)

    file_data, error = validate_file_data(data)

    if error:
        return jsonify({"error": error}), 400

    conn = get_db()

    cursor = conn.execute("""
        INSERT INTO files
        (name, size, value, category)
        VALUES (?, ?, ?, ?)
    """, (
        file_data["name"],
        file_data["size"],
        file_data["value"],
        file_data["category"]
    ))

    conn.commit()

    file_id = cursor.lastrowid

    conn.close()

    return jsonify({
        "message": "File added successfully",
        "file": {
            "id": file_id,
            **file_data
        }
    }), 201


# =========================================================
# DELETE ONE FILE
# =========================================================

@app.route("/api/files/<int:file_id>", methods=["DELETE"])
def delete_file(file_id):

    conn = get_db()

    cursor = conn.execute(
        "DELETE FROM files WHERE id = ?",
        (file_id,)
    )

    conn.commit()
    conn.close()

    if cursor.rowcount == 0:
        return jsonify({
            "error": "File not found"
        }), 404

    return jsonify({
        "message": "File deleted successfully"
    })


# =========================================================
# DELETE ALL FILES
# =========================================================

@app.route("/api/files", methods=["DELETE"])
def delete_all_files():

    conn = get_db()

    conn.execute("DELETE FROM files")

    conn.commit()
    conn.close()

    return jsonify({
        "message": "All files deleted successfully"
    })


# =========================================================
# SAMPLE FILES
# =========================================================

@app.route("/api/sample", methods=["POST"])
def load_sample():

    samples = [
        {
            "name": "Quarterly Report",
            "size": 250,
            "value": 90,
            "category": "Documents"
        },
        {
            "name": "Project Presentation",
            "size": 300,
            "value": 85,
            "category": "Documents"
        },
        {
            "name": "Family Videos",
            "size": 700,
            "value": 65,
            "category": "Videos"
        },
        {
            "name": "Important Photos",
            "size": 350,
            "value": 75,
            "category": "Photos"
        },
        {
            "name": "Old Logs",
            "size": 150,
            "value": 20,
            "category": "Logs"
        },
        {
            "name": "Database Backup",
            "size": 450,
            "value": 95,
            "category": "Backup"
        },
        {
            "name": "Music Collection",
            "size": 500,
            "value": 45,
            "category": "Music"
        },
        {
            "name": "Research Papers",
            "size": 200,
            "value": 80,
            "category": "Documents"
        }
    ]

    conn = get_db()

    for file in samples:
        conn.execute("""
            INSERT INTO files
            (name, size, value, category)
            VALUES (?, ?, ?, ?)
        """, (
            file["name"],
            file["size"],
            file["value"],
            file["category"]
        ))

    conn.commit()
    conn.close()

    return jsonify(get_all_files())


# =========================================================
# 0/1 KNAPSACK
# =========================================================

def knapsack(files, capacity):

    n = len(files)

    # DP table
    dp = [
        [0 for _ in range(capacity + 1)]
        for _ in range(n + 1)
    ]

    # Build DP table
    for i in range(1, n + 1):

        file_size = files[i - 1]["size"]
        file_value = files[i - 1]["value"]

        for w in range(capacity + 1):

            if file_size <= w:

                dp[i][w] = max(
                    dp[i - 1][w],
                    file_value + dp[i - 1][w - file_size]
                )

            else:

                dp[i][w] = dp[i - 1][w]

    # Reconstruct selected files
    selected = []

    w = capacity

    for i in range(n, 0, -1):

        if dp[i][w] != dp[i - 1][w]:

            selected.append(files[i - 1])

            w -= files[i - 1]["size"]

    selected.reverse()

    total_size = sum(f["size"] for f in selected)
    total_value = sum(f["value"] for f in selected)

    # Build trace
    selected_ids = {f["id"] for f in selected}

    trace = []

    for file in files:

        if file["id"] in selected_ids:

            trace.append({
                "file": file["name"],
                "action": "take",
                "reason": (
                    "Included in the optimal solution "
                    "because it contributes to the maximum "
                    "total importance."
                )
            })

        else:

            trace.append({
                "file": file["name"],
                "action": "skip",
                "reason": (
                    "Not selected because including it would "
                    "not improve the optimal total value."
                )
            })

    return selected, total_size, total_value, trace


# =========================================================
# GREEDY
# =========================================================

def greedy_algorithm(files, capacity):

    files_with_ratio = []

    for file in files:

        ratio = file["value"] / file["size"]

        file_copy = file.copy()
        file_copy["ratio"] = round(ratio, 4)

        files_with_ratio.append(file_copy)

    # Highest value/size first
    files_with_ratio.sort(
        key=lambda x: x["ratio"],
        reverse=True
    )

    selected = []

    current_size = 0
    current_value = 0

    trace = []

    for file in files_with_ratio:

        if current_size + file["size"] <= capacity:

            selected.append(file)

            current_size += file["size"]
            current_value += file["value"]

            trace.append({
                "file": file["name"],
                "action": "take",
                "reason": (
                    f"Highest available value/size ratio "
                    f"({file['ratio']}) and it fits."
                )
            })

        else:

            trace.append({
                "file": file["name"],
                "action": "skip",
                "reason": (
                    f"Value/size ratio is {file['ratio']}, "
                    "but the file does not fit in the remaining capacity."
                )
            })

    return selected, current_size, current_value, trace


# =========================================================
# SOLVE / COMPARE
# =========================================================

@app.route("/api/solve", methods=["POST"])
def solve():

    data = request.get_json(silent=True)

    if not data or "capacity" not in data:
        return jsonify({
            "error": "capacity is required"
        }), 400

    try:
        capacity = int(data["capacity"])
    except (ValueError, TypeError):
        return jsonify({
            "error": "capacity must be a number"
        }), 400

    if capacity <= 0:
        return jsonify({
            "error": "capacity must be greater than 0"
        }), 400

    files = get_all_files()

    if not files:
        return jsonify({
            "error": "No files available. Add files first."
        }), 400

    # ---------------- KNAPSACK ----------------

    k_selected, k_size, k_value, k_trace = knapsack(
        files,
        capacity
    )

    # ---------------- GREEDY ----------------

    g_selected, g_size, g_value, g_trace = greedy_algorithm(
        files,
        capacity
    )

    # ---------------- COMPARISON ----------------

    gap = k_value - g_value

    if k_value > 0:
        efficiency = round(
            (g_value / k_value) * 100,
            2
        )
    else:
        efficiency = 100

    notes = [
        f"The storage capacity is {capacity} MB.",
        f"0/1 Knapsack stores {k_value} importance points.",
        f"Greedy stores {g_value} importance points."
    ]

    if gap == 0:
        notes.append(
            "Both algorithms produced the same total importance."
        )
    else:
        notes.append(
            f"Greedy is {gap} importance points below "
            "the optimal Knapsack solution."
        )

    return jsonify({

        "capacity": capacity,

        "notes": notes,

        "runs": [

            {
                "algorithm": "0/1 Knapsack",
                "optimal": True,
                "complexity": "Dynamic Programming: O(n × capacity)",
                "capacity": capacity,
                "selected": k_selected,
                "total_size": k_size,
                "total_value": k_value,
                "remaining_capacity": capacity - k_size,
                "gap": 0,
                "efficiency": 100,
                "trace": k_trace
            },

            {
                "algorithm": "Greedy",
                "optimal": False,
                "complexity": "Sort by value/size ratio: O(n log n)",
                "capacity": capacity,
                "selected": g_selected,
                "total_size": g_size,
                "total_value": g_value,
                "remaining_capacity": capacity - g_size,
                "gap": gap,
                "efficiency": efficiency,
                "trace": g_trace
            }

        ]
    })


# =========================================================
# ERROR HANDLERS
# =========================================================

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found"
    }), 404


@app.errorhandler(405)
def method_not_allowed(error):
    return jsonify({
        "error": "HTTP method not allowed"
    }), 405


@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "error": "Internal server error"
    }), 500


# =========================================================
# RUN SERVER
# =========================================================

if __name__ == "__main__":

    init_db()

    print("=" * 60)
    print("File Storage Packing Optimizer")
    print("Server: http://127.0.0.1:5000")
    print("=" * 60)

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )